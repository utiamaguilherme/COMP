#ifndef _TOKEN_H_
#define _TOKEN_H_


#define T_INTEGER 	10
#define T_FLOAT		11

#define T_PLUS		60
#define T_MINUS		61
#define T_MUL		62
#define T_DIV		63

#define T_AP		70
#define T_FP		71
#define T_END       80


#endif
