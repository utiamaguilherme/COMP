#define max_tabela 100

enum {
  E_INT, E_FLOAT, E_STRING
};

typedef struct tupla {
  char c;
  int intval;
} tuple;

typedef struct simbolos {
  char * nome;
  int tipo;
} VAR;

VAR tabela_simbolos[max_tabela];

void define_tipo(int);
void declaracao(char *c);
int find(char *c);
tuple * get(char * c);
