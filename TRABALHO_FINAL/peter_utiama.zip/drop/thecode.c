#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "thecode.h"
#include "listadin.h"

TC_ROW *theTableOfCode;
int codePos;
int labelCount;


void thc_init(){
    codePos = 0;
    labelCount = 0;
}

int thc_nextInst(){
    return codePos;
}

int thc_novolabel(){
    char v[10];
    sprintf(v,"L%d:", labelCount);
    thc_addCode(v, "");
    labelCount++;
    return labelCount -1;

}

void thc_backpath(int pos, int par){
    char v[10];
    sprintf(v, "%d", par);
    free(theTableOfCode[pos].par1);
    theTableOfCode[pos].par1 = strdup(v);
}

void thc_backpathAll(LISTD *l, int label){
    int a;
    if(l==NULL) return;
    while(listd_getIndex(l,0,&a)){
        thc_backpath(a,label);
        listd_removeIndex(l,0);
    }
}

void thc_addCode(char *inst, char *par){
    theTableOfCode = (TC_ROW *)realloc(theTableOfCode, sizeof(TC_ROW)*(codePos+1));
    theTableOfCode[codePos].inst = strdup(inst);
    theTableOfCode[codePos].par1 = strdup(par);
    codePos++;
}

void thc_printCode(){
    int i;
    for(i=0;i<codePos;i++){
        printf("%s %s\n", theTableOfCode[i].inst, theTableOfCode[i].par1);
    }
}

void thc_openMethod(char *name){
    char *a;
    char *head = ".method public static %s([Ljava/lang/String;)V";
    a = malloc(sizeof(char)*(strlen(name)+strlen(head)+10));
    a[0] = '\0';
    sprintf(a, head, name);
    thc_addCode(a,"");
    thc_addCode("  .limit stack 50",""); //TODO: deve-se contar o tamanho de pilha necessario
    thc_addCode("  .limit locals 50","");//TODO: deve-se contar a quantidade de variaveis necessarias
    free(a);
}

void thc_closeMethod(){
    thc_addCode(".end method\n\n","");
}

void thc_generateReadIntCode(){
    thc_addCode("invokestatic","java/lang/System/console()Ljava/io/Console;");
    thc_addCode("invokevirtual","java/io/Console/readLine()Ljava/lang/String;");
    thc_addCode("invokestatic","java/lang/Integer/parseInt(Ljava/lang/String;)I");
}

void thc_generateOutputFile(char *filenameWithOutExtension){
    char *a;
    FILE *f;
    int i;
    a = malloc(sizeof(char)*(strlen(filenameWithOutExtension)+5));
    a[0] = '\0';
    strcat(a,filenameWithOutExtension);
    strcat(a, ".j");


    f = fopen(a, "w");
    fprintf(f,".class public %s\n", filenameWithOutExtension);
    fprintf(f,".super java/lang/Object\n\n");

    fprintf(f,".method public <init>()V\n");
    fprintf(f,"  aload_0\n");

    fprintf(f,"  invokenonvirtual java/lang/Object/<init>()V\n");
    fprintf(f,"  return\n");
    fprintf(f,".end method\n\n");

    for(i=0;i<codePos;i++){
        fprintf(f,"  %s %s\n", theTableOfCode[i].inst, theTableOfCode[i].par1);
    }
    free(a);
    fclose(f);
}
