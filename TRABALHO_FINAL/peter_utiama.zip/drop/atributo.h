

#ifndef _ATRIBUTO_
#define _ATRIBUTO_ 1

#include "listadin.h"

struct _atributo{
  int intval;
  float f;
  char *strval;
  LISTD *listav;
	LISTD *listaf;
  int tipo;
	int label;
};

char * labelGoto;

typedef struct _atributo ATRIBUTO;

#endif // _ATRIBUTO_
