#include <stdio.h>
#include <stdlib.h>
#include "expr.h"
#include "atributo.h"

int tipo;

void define_tipo(int i){
	tipo = i;
}

void init(){
	for(int i=0; i<max_tabela; i++){
		tabela_simbolos[i].nome = "\0";
		tabela_simbolos[i].tipo = 0;
	}
}

void declaracao(char * c){
	// printf("declarando %s\t", c);
	for(int i=0; i<max_tabela; i++){
		if(strcmp(tabela_simbolos[i].nome,"\0") == 0){
			tabela_simbolos[i].tipo = tipo;
			tabela_simbolos[i].nome = strdup(c); // Declara o nome da variavel
			// printf("declarado %s do tipo %d\n", tabela_simbolos[i].nome, tabela_simbolos[i].tipo);
			return;
		}
	}

	printf("nao declarado %s\n", c);

}

int find(char *c){
	//printf("finding %s\t", c);
	for(int i=0; i<max_tabela; i++){
    printf("%d", i);
		if(strcmp(tabela_simbolos[i].nome, c) == 0){
			return i;
		}
	}
	//printf("not found\n");
	return -1;
}

int findAndType(char *c){
	//printf("finding %s\t", c);
	for(int i=0; i<max_tabela; i++){
		if(strcmp(tabela_simbolos[i].nome, c) == 0){
			if(tabela_simbolos[i].tipo == E_INT){
				printf("i");
			} else if(tabela_simbolos[i].tipo == E_FLOAT){
				printf("f");
			}else if(tabela_simbolos[i].tipo == E_STRING){
				printf("s");
			}
			return i;
		}
	}
	//printf("not found\n");
	return -1;
}

tuple * get(char *c){

  tuple * temp = (tuple*)malloc(sizeof(tuple));
	for(int i=0; i<max_tabela; i++){
		if(strcmp(tabela_simbolos[i].nome, c) == 0){
			temp->intval = i;
			if(tabela_simbolos[i].tipo == E_INT){
				temp->c = 'i';
			} else if(tabela_simbolos[i].tipo == E_FLOAT){
				temp->c = 'f';
      }
			return temp;
		}
	}
	temp->intval=0x3f3f3f3f;
	temp->c='e';
	return temp;
}
