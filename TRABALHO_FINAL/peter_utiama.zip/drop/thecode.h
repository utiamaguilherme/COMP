
#ifndef _THECODE_
#define _THECODE_ 1

#include "listadin.h"

struct tc_row{
    char * inst;
    char * par1;
};

typedef struct tc_row TC_ROW;

void thc_init();
void thc_addCode(char *inst, char *par);
void thc_printCode();
int thc_nextInst();
int thc_novolabel();
void thc_backpathAll(LISTD *l, int label);
void thc_generateOutputFile(char *filenameWithOutExtension);

void thc_openMethod(char *name);
void thc_closeMethod();
void thc_generateReadIntCode();

#endif // _THECODE_
