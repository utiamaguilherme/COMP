#include <stdio.h>
#include "atributo.h"
#include "thecode.h"
#include "expr.tab.c"

extern FILE *yyin;

int main(int argc, char *argv[])
{
  FILE *in;

  init();
  thc_init();

  in = fopen(argv[1],"r");
	yyin = in;
	if(yyparse()==0){
        printf("SUCESSO\n");
        thc_printCode();
        thc_generateOutputFile("theoutput");
        //colocar o seu caminho ate o jasmin aqui...
        //system("java -jar \"C:\\Users\\LeandroP.LEANDRO\\Documents\\jasmin-2.4\\jasmin.jar\" theoutput.j");
	}else{
        printf("ERRO\n");
	}
	//thc_printCode();

	return 0;
}
